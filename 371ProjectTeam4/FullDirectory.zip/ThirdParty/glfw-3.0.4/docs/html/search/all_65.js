var searchData=
[
  ['error_20handling',['Error handling',['../group__error.html',1,'']]],
  ['error_20codes',['Error codes',['../group__errors.html',1,'']]]
];
